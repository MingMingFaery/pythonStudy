#include "TypeDef.h"

Move::Move(int flip0, int inItem0, int outItem0) {
    flip = flip0;
    inItem = inItem0;
    outItem = outItem0;
}

void Move::copy(const Move& move){
    flip = move.flip;
    in = move.in;
    inItem = move.inItem;
    outItem = move.outItem;
    obj = move.obj;
    eva = move.eva;
    feasible = move.feasible;
    feaNum = move.feaNum;
}

void Move::printMove() const {
    printf("FlipLoc: %3d\n", flip);
    printf("obj    : %7d\n", obj);
    printf("fea    : %7f\n", feasible);
    printf("eva    : %7f\n", eva);
}

Tabu_Sol::Tabu_Sol(int itemNum) {
    length = long(pow(10, 8) * 2);
    gamma1 = 0.4;
    gamma2 = 1.6;
    gamma3 = 1.3;

    hash1 = new bool [length] {false};
    hash2 = new bool [length] {false};
    hash3 = new bool [length] {false};
    weight1 = new long long [itemNum] {0};
    weight2 = new long long [itemNum] {0};
    weight3 = new long long [itemNum] {0};
    for (int item = 0; item < itemNum; ++item) {
        weight1[item] = pow(item + 1, gamma1);
        weight2[item] = pow(item + 100, gamma2);
        weight3[item] = pow(itemNum - item + 1, gamma3);
        //        cout << item << ":" << weight1[item] <<"  " << weight2[item] <<"  " << weight3[item] << endl;
    }

}

Tabu_Sol::~Tabu_Sol() {
    delete[] hash1;
    delete[] hash2;
    delete[] hash3;
    delete[] weight1;
    delete[] weight2;
    delete[] weight3;
}

void Tabu_Sol::tabuSol(const Solution& sol) const {
    long long loc1 = sol.tabuLoc[0];
    long long loc2 = sol.tabuLoc[1];
    long long loc3 = sol.tabuLoc[2];
    hash1[loc1 % length] = true;
    hash2[loc2 % length] = true;
    hash3[loc3 % length] = true;

    //    cout << "solution is tabu!" << sol.obj << endl;
}

bool Tabu_Sol::judgeTabu(const Solution& sol, const Move& move) {
    long long loc1 = sol.tabuLoc[0];
    long long loc2 = sol.tabuLoc[1];
    long long loc3 = sol.tabuLoc[2];
    if (move.flip >= 0) {
        loc1 = loc1 + move.in * weight1[move.flip];
        loc2 = loc2 + move.in * weight2[move.flip];
        loc3 = loc3 + move.in * weight3[move.flip];
    }
    else if (move.inItem >= 0 && move.outItem >= 0) {
        if (!sol.select[move.inItem] && sol.select[move.outItem]) {
            loc1 = loc1 + weight1[move.inItem] - weight1[move.outItem];
            loc2 = loc2 + weight2[move.inItem] - weight2[move.outItem];
            loc3 = loc3 + weight3[move.inItem] - weight3[move.outItem];
        }
        else {
            cout << "mistake!" << endl;
        }
    }
    else {
        cout << "Other!" << endl;
    }
    if (hash1[loc1 % length] && hash2[loc2 % length] && hash3[loc3 % length]) {
        tabuNum++;
        //        cout << "solution has been tabu!" << move.obj << endl;
        return true;
    }
    else {
        return false;
    }

}
