#include "TypeDef.h"

int main() {
    string input_file = R"(../ins/100-30-30-1-5-15.txt )";
    Instance ins(input_file);
    Input input(10);
    input.timeLimit = 1.5;
    Output output;
    Solution sol(ins,input.gammaBase);
    sol.initialize_random(ins);
    Frequency fModel(ins);
    firstSearch(ins,sol,fModel,input,output);
    return 0;
}
