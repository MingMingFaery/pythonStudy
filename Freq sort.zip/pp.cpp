#include "TypeDef.h"

void pp(){
    cout << "pp" << endl;
}