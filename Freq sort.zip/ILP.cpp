#include "TypeDef.h"

/*
The following code runs on PC of envy 

#include <ilcplex/ilocplex.h>



ILP::ILP(const Instance& ins) {
	size = ins.itemNum;
	x = new double[size];
	score = new float[size];
	k = 0;
	intNum = size;
	IloEnv env;
	try {
		// Add variable
		//ILOFLOAT,ILOINT,ILOBOOL is float,int,bool
		IloNumVarArray vars(env);
		for (int item = 0;item < ins.itemNum;item++) {
			vars.add(IloNumVar(env, 0, 1, ILOFLOAT));
		}
		// Add constraint
		IloModel model(env);
		for (int attr = 0;attr < ins.attrNum;attr++) {
			IloExpr expr(env);
			for (int item = 0; item < ins.itemNum; item++) {
				expr += vars[item] * ins.resource[attr][item];
			}
			if (ins.attrType[attr] == 1) {
				model.add(expr <= ins.threshold[attr]);
			}else {
				model.add(expr >= ins.threshold[attr]);
			}
		}
		// Add objective
		IloExpr obj(env);
		for (int item = 0; item < ins.itemNum; item++) {
			obj += vars[item] * ins.profit[item];
		}
		model.add(IloMaximize(env, obj));
		// solve
		IloCplex cplex(model);
		cplex.setOut(env.getNullStream());
		if (!cplex.solve()) {
			env.error() << "Failed to optimize LP." << endl;
			throw(-1);
		}
		IloNumArray vals(env);
		objValue = cplex.getObjValue();
		cplex.getValues(vals, vars);
		for (int index = 0;index < ins.itemNum;index++) {
			x[index] = vals[index];
			k += vals[index];
			if (vals[index] > 0 && vals[index] < 1) {
				intNum--;
			}
		}
	}
	catch (IloException& e){
		cerr << "Concert exception caught: " << e << endl;
	}
	catch (...) { cerr << "Unknown exception caught" << endl; }

	env.end();
}

*/

ILP::ILP(const Instance& ins) {
	size = ins.itemNum;
	x = new double[size];
	score = new float[size];
	k = size;
	intNum = size;
	objValue = 0;
	for (int index = 0;index < ins.itemNum;index++) {
		x[index] = 1;
		objValue += ins.profit[index];
	}

}

void ILP::printILP(){
	printf("the object value: %.2f\n", objValue);
	printf("the k value     : %.2f\n", k);
	printf("the int item num: %d\n", intNum);
}

void ILP::calculate(const Solution& sol){
	if (sol.itemNum != size) {
		cerr << "The size of relax solution and feasible solution are different!!" << size << "/" << sol.itemNum << endl;
	}
	for (int item = 0;item < size;item++) {
		score[item] = abs(x[item] - sol.select[item]);
	}
}

ILP::~ILP(){
	delete[] x;
	delete[] score;
	//cout << "x has been release!" << endl;
}

Fix::Fix(const Solution& subSol, const float* score, int total,const int* preFixed) {
	isNum = 0;
	areNum = 0;
	size = subSol.itemNum;
	Sort s(score, size);
	subisFixed = new int[size] {0};
	subareFixed = new int[size] {0};
	isFixed = new int[total] {0};
	areFixed = new int[total] {0};
	for (int item = 0;item < size;item++) {
		if (item >= size / 2) { // is is much
			subisFixed[s.index[item]] = subSol.select[s.index[item]] * 2 - 1;
			isNum++;
		}
		else {
			subareFixed[s.index[item]] = subSol.select[s.index[item]] * 2 - 1;
			areNum++;
		}
	}
	int index = 0;
	for (int item = 0;item < total;item++) {
		if (preFixed[item] == -1 || preFixed[item] == 1) {
			isFixed[item] = preFixed[item];
			areFixed[item] = preFixed[item];
			isNum++;
			areNum++;
		}
		else {
			isFixed[item] = subisFixed[index];
			areFixed[item] = subareFixed[index];
			index++;
		}
	}

}

Fix::Fix(int size){
	subisFixed = new int[size] {0};
	subareFixed = new int[size] {0};
	isFixed = new int[size] {0};
	areFixed = new int[size] {0};
}

Fix::~Fix(){
	delete[] subisFixed;
	delete[] subareFixed;
	delete[] isFixed;
	delete[] areFixed;
}
