#include "TypeDef.h"


void flipNeighbor(const Instance& ins, const Solution& sol, vector<Move> & moves, Tabu_Sol& tabu, double flipTime) {
    clock_t begin = clock();
    for (int item = 0; item < ins.itemNum; ++item) {
        Move move(item);
        if (sol.select[item]) move.in = -1;
        move.obj = sol.obj + move.in * ins.profit[item];
        for (int attr = 0; attr < ins.attrNum; ++attr) {
            int attrFeasible;
            attrFeasible = sol.attrFeasible[attr] - ins.attrType[attr] * move.in * ins.resource[attr][item];
            if (attrFeasible < 0) {
                move.feaNum++;
                move.feasible += -attrFeasible * sol.attrGamma[attr];
            }
        }
        move.eva = move.obj - move.feasible;
        if (!tabu.judgeTabu(sol, move)) {
            Func::updateMoves(moves, move);
        }
    }
    clock_t end = clock();
    flipTime += (double)(end - begin) / CLOCKS_PER_SEC;
}
void swapNeighbor(const Instance& ins, const Solution& sol, vector<Move> & moves, Tabu_Sol& tabu,double swapTime) {
    clock_t begin = clock();
    for (int inItem = 0; inItem < ins.itemNum; ++inItem) {
        if (sol.select[inItem] == 1) continue;
        for (int outItem = 0; outItem < ins.itemNum; ++outItem) {
            if (sol.select[outItem] == 0) continue;
            Move move(EMPTY, inItem, outItem);
            move.obj = sol.obj + ins.profit[inItem] - ins.profit[outItem];
            for (int attr = 0; attr < ins.attrNum; ++attr) {
                int attrFeasible;
                attrFeasible = sol.attrFeasible[attr] - ins.attrType[attr] * (ins.resource[attr][inItem] - ins.resource[attr][outItem]);
                if (attrFeasible < 0) {
                    move.feaNum++;
                    move.feasible += -attrFeasible * sol.attrGamma[attr];
                }
            }
            move.eva = move.obj - move.feasible;
            clock_t tempTime = clock();
            if (!tabu.judgeTabu(sol, move)) {
                Func::updateMoves(moves, move);
            }
        }
    }
    clock_t end = clock();
    swapTime += (double)(end - begin) / CLOCKS_PER_SEC;
}

void firstSearch(const Instance& ins, Solution& sol, Frequency& fModel, Input& input, Output& output) {
    // This search input the main instance and output a feasible solution with the limit of time
    Solution tempSol(ins);
    tempSol.beCovered(sol);
    Tabu_Sol tabu(ins.itemNum);
    tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
    output.iter = 0;
    output.stagnant = 0;
    vector<Move> moves;
    while (sol.feaNum != 0 && output.totalTime < input.timeLimit ) {
        output.iter++;
        output.stagnant++;
        flipNeighbor(ins, tempSol, moves, tabu, output.flipTime);
        swapNeighbor(ins, tempSol, moves, tabu, output.swapTime);
        if (!moves.empty()) {
            tempSol.execute(ins, moves[rand()%moves.size()], input);
            tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
            fModel.updateFreq(tempSol);
            tabu.tabuSol(tempSol);
            moves.clear();
            if ((((tempSol.feasible == 0 && sol.feasible == 0) || (tempSol.feasible != 0 && sol.feasible != 0)) && tempSol.eva > sol.eva) || (tempSol.feasible == 0 && sol.feasible != 0)) {
                sol.beCovered(tempSol);
                output.stagnant = 0;
                clock_t end = clock();
                output.findBestTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
            }
        }
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output::formati(output.iter, 4) + Output::formati(output.stagnant, 4) + 
            Output::formatf(output.totalTime) + 
            Output::formati(tempSol.obj, 10) + Output::formati(tempSol.eva, 10) +
            Output::formati(tempSol.feaNum) + Output::formati(tempSol.k, 5) + Output::formati(sol.obj) +  "\n";
        cout << tempStr;
    }
}


void secondSearch(const SubInstance& ins, Solution& sol, Frequency& fModel, Input& input, Output& output) {
    // This search input the main instance and output a feasible solution with the limit of time
    Solution tempSol(ins);
    tempSol.beCovered(sol);
    Tabu_Sol tabu(ins.itemNum);
    tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
    output.iter = 0;
    output.stagnant = 0;
    vector<Move> moves;
    while (output.stagnant<input.improveCut && output.totalTime < input.timeLimit ) {
        output.iter++;
        output.stagnant++;
        flipNeighbor(ins, tempSol, moves, tabu, output.flipTime);
        swapNeighbor(ins, tempSol, moves, tabu, output.swapTime);
        if (!moves.empty()) {
            tempSol.execute(ins, moves[rand()%moves.size()], input);
            tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
            fModel.updateFreq(tempSol);
            tabu.tabuSol(tempSol);
            moves.clear();
            if ((((tempSol.feasible == 0 && sol.feasible == 0) || (tempSol.feasible != 0 && sol.feasible != 0)) && tempSol.eva > sol.eva) || (tempSol.feasible == 0 && sol.feasible != 0)) {
                sol.beCovered(tempSol);
                output.stagnant = 0;
                clock_t end = clock();
                output.findBestTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
            }
        }
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output::formati(output.iter, 4) + Output::formati(output.stagnant, 4) + 
            Output::formatf(output.totalTime) + 
            Output::formati(tempSol.obj, 10) + Output::formati(tempSol.eva, 10) +
            Output::formati(tempSol.feaNum) + Output::formati(tempSol.k, 5) + Output::formati(sol.obj) +  "\n";
        cout << tempStr;
    }
}

void tabuSearch(const SubInstance& ins, Solution& sol, Frequency& fModel, Input& input, Output& output) {
    Solution tempSol(ins);
    tempSol.beCovered(sol);
    Tabu_Sol tabu(ins.itemNum);
    tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
    output.iter = 0;
    output.stagnant = 0;
    vector<Move> moves;
    while ((!input.fea && sol.feaNum!=0 && output.totalTime < input.timeLimit/3) || (input.fea && output.totalTime < input.subTimeLimit && output.stagnant < input.improveCut)) {
        output.iter++;
        output.stagnant++;
        flipNeighbor(ins, tempSol, moves, tabu, output.flipTime);
        swapNeighbor(ins, tempSol, moves, tabu, output.swapTime);
        if (!moves.empty()) {
            tempSol.execute(ins, moves[rand()%moves.size()], input);
            tempSol.getTabuScore(tabu.weight1, tabu.weight2, tabu.weight3);
            fModel.updateFreq(tempSol);
            tabu.tabuSol(tempSol);
            if ((((tempSol.feasible == 0 && sol.feasible == 0) || (tempSol.feasible != 0 && sol.feasible != 0)) && tempSol.eva > sol.eva) || (tempSol.feasible == 0 && sol.feasible != 0)) {
                sol.beCovered(tempSol);
                output.stagnant = 0;
                clock_t end = clock();
                output.findBestTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
            }
        }
        else {
            output.emptyNum++;
        }
        if (sol.feaNum == 0) {
            fModel.lastSolFea = true;
            input.fea = true;
        }
        else {
            fModel.lastSolFea = false;
        }
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
    }
}

void iterSearch(const Instance& ins, Input& input, Output& totalOutput) {
    Frequency fModel(ins);
    Solution sol(ins);
    Solution bestSol(ins);
    ILP solver(ins);
    fModel.initial(solver);
    while (totalOutput.iter < input.allIter && totalOutput.totalTime < input.timeLimit && totalOutput.stagnant < 30) {
        totalOutput.iter++;
        totalOutput.stagnant++;
        // the first search
    //        input.subTimeLimit = input.timeLimit/(0.6*input.allIter+totalOutput.iter);
    //        input.subTimeLimit = input.timeLimit/1.5/input.allIter + 0.15 * (input.timeLimit - input.timeLimit/1.5 - totalOutput.totalTime + (totalOutput.iter-1)*input.timeLimit/1.5/input.allIter);
        input.subTimeLimit = (input.timeLimit - totalOutput.totalTime) / (input.allIter - totalOutput.iter + 1);
        //        input.improveCut = (int) (input.improveCut *(1.0+input.improveCutAdd));
        //        input.improveCut = (int) (1.0*input.improveCut - 30000.0/input.allIter + 30000.0/(1.2*input.allIter - totalOutput.iter));
        fModel.fixNum =  (int) (ins.itemNum* (1.0-( 1.0/((1.0*ins.itemNum/1000)*(totalOutput.iter-1) + 1.0/(1.0 - input.cutRate) ) + input.cutRate)) );
        //fModel.fixNum = 0;
        fModel.updateFixed();
        Output output;
        SubInstance subIns(ins, fModel.isFixed);
        printf("create subIns -> fixNum:%3d,leaveObj:%7d\n", fModel.fixNum, subIns.leaveObj);
        ILP subSolver(subIns);
        input.k = subSolver.k;
        Frequency subFreq(subIns);
        Solution subSol(subIns);
        subSol.initialize_random(subIns,input.gammaBase);
        tabuSearch(subIns, subSol, subFreq, input, output);
        sol.restoreSol(subSol, ins, subIns);
        if (sol.feaNum == 0 && sol.obj > bestSol.obj) {
            totalOutput.stagnant = 0;
            totalOutput.findBestTime = totalOutput.totalTime + output.findBestTime;
            bestSol.beCovered(sol);
        }
        fModel.restoreFreq(subFreq, subIns);
        totalOutput.getSubInfo(output);
        clock_t end = clock();
        totalOutput.totalTime = (double)(end - totalOutput.beginTime) / CLOCKS_PER_SEC;
        string tempStr = Output::formati(totalOutput.iter, 4) + Output::formati(totalOutput.stagnant, 4) + Output::formati(output.iter) +
            Output::formatf(output.totalTime) + Output::formatf(totalOutput.totalTime) +
            Output::formati(subIns.itemNum, 5) + Output::formati(subSol.obj, 10) +
            Output::formati(sol.obj) + Output::formati(sol.feaNum) + Output::formati(sol.k, 5) + Output::formati(bestSol.obj) + "\n";
        cout << tempStr;
        totalOutput.iter_info += tempStr;
        //        if (totalOutput.iter%5==0){
        //            printf("No.%4d,ins.%s.obj = %7d\n",totalOutput.iter,ins.insName.c_str(),bestSol.obj);
        //        }
    }
    ins.printInformation(totalOutput);
    input.printInput(totalOutput);
    totalOutput.printOutput();
    bestSol.printInformation(totalOutput);
    bestSol.check(ins, totalOutput);
    cout << "tabuNum:" << totalOutput.tabuNum << endl;
}

void SEARCH(const Instance & ins ,Solution & sol,double timeLimit){
    
    Output output{};
    Input input(200);
    Frequency fModel(ins);
    input.timeLimit = 0.3 * timeLimit;
    while (sol.feaNum!=0 && output.totalTime < timeLimit){
        cout << "Begin first Search!" << endl;
        fModel.initial();
        Output firstOutput{};
        sol.initialize_random(ins,input.gammaBase);
        firstSearch(ins,sol,fModel,input,firstOutput);
        clock_t end = clock();
        output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
    }
    cout << "End first Search!" << endl;
    ILP solver(ins);
    solver.calculate(sol);
    fModel.getFreqScore();
    fModel.fixNum = 50;
    fModel.updateFixed(sol.select,solver.score,0.5);
    cout << "End select fixed item!" << endl;
    
    // while (output.totalTime < timeLimit){
    //     SubInstance sIns(ins,fModel.isFixed);
    //     Solution sSol(sIns);
    //     sSol.initialize_random(sIns,input.gammaBase);
    //     cout << "Creat sub Ins!" << sIns.itemNum << endl;
    //     fModel.initial();
    //     Output secondOutput{};
    //     secondSearch(sIns,sSol,fModel,input,secondOutput);
    //     clock_t end = clock();
    //     output.totalTime = (double)(end - output.beginTime) / CLOCKS_PER_SEC;
    // }
}