#ifndef MDMKP_TYPEDEF_H
#define MDMKP_TYPEDEF_H
#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <list>
#include <valarray>
#include <stdio.h>
#include <ctime>
using namespace std;
#define MAXVALUE 99999999
#define EMPTY (-1)

//ǰ������
class Tabu_new ;

class Output {
public:
    Output();
    void printOutput();
    void output(const string& file) const;
    void output_sol(const string& file) const;
    static string format(const string& str, int length = 8);
    static string formati(const int& a, int length = 8);
    static string formatf(const float& b, int length = 8);
    void getSubInfo(const Output& subOutput);


    clock_t beginTime{};
    double totalTime{};
    double findBestTime{};
    int iter{};
    int stagnant{};
    int emptyNum{};
    double swapTime{};
    double flipTime{};
    string output_info{};
    string iter_info{};
    string sol_temp{};
    double updateTime{};
    int tabuNum{};
};

class Input {
public:
    Input(int seed);
    void printInput(Output& output) const;
    void inputInitial(int seed0, double timeLimit0 = 1.0, int improveCut0 = 10000,
        double gamma0 = 0.2, double gamma_base0 = 0.1);
    bool fea{};
    int seed{};
    double k{};
    int improveCut{};
    double subTimeLimit{};
    double gamma{};
    double gammaBase{};
    int allIter{};
    double timeLimit{};
    int improveCutAdd{};
    double cutRate{};
};

class Move {
public:
    explicit Move(int flip0 = EMPTY, int inItem = EMPTY, int outItem = EMPTY);
    void copy(const Move& move);
    void printMove() const;
    // flip
    int flip = EMPTY;
    int in = 1;
    // swap
    int inItem = EMPTY;
    int outItem = EMPTY;

    int obj = EMPTY;
    double eva = -MAXVALUE;
    double feasible = 0;
    int feaNum = 0;
};

class Instance {
public:
    explicit Instance(string file);
    Instance();
    void printInformation(Output& output) const;
    ~Instance();
    string insName{};
    int itemNum{};
    int upperNum{};
    int floorNum{};
    int attrNum{};
    int* profit{};
    int* threshold{};
    int* attrType{};
    int** resource{};
};

class SubInstance : public Instance {
public:
    SubInstance(const Instance& ins, const int* isFixed);
    SubInstance(int itemNum,int upperNum,int floorNum,int totalItemNum);
    void beCovered(const SubInstance& ins,int total);
    ~SubInstance();

    int mainItemNum{};
    int leaveObj{};
    int* fixed{};
};

class Solution {
public:
    explicit Solution(const Instance& ins);
    ~Solution();
    void initialize_random(const Instance& ins, double gammaBase);
    void evaluate(const Instance& ins);
    void printInformation(Output& output) const;
    void printSol(const Instance& ins) const;
    void execute(const Instance& ins, Move move, const Input& input);
    void beCovered(const Solution& sol);
    void output(const string& file, const Instance& ins) const;
    void save_solution(const Instance& ins, Output& output) const;
    void check(const Instance& ins, Output& output) const;
    void getTabuScore(const long long* weight1, const long long* weight2, const long long* weight3) const;
    void getTabuScore(Tabu_new & tabu,const SubInstance & subIns) const;
    void restoreSol(const Solution& subSol, const Instance& mainIns, const SubInstance& subIns);


    int itemNum{};
    int attrNum{};
    int k{};
    int obj{};     //Ŀ��ֵ
    double feasible{}; // ���н�
    double gamma = 1.0;
    double eva{};
    int feaNum{};
    bool* select{};
    int* attrFeasible{};
    int* occupy{};
    double* attrGamma{};
    long long* tabuLoc{};
};

class ILP {
public:
    ILP(const Instance & ins);
    void printILP();
    void calculate(const Solution& sol);
    ~ILP();

    int size{};
    double objValue{};
    double k{};
    int intNum{};
    double* x{};
    float* score{};

};

class Fix {
public:
    Fix(const Solution& subSol, const float* score, int total,const int* preFixed);
    Fix(int size);
    ~Fix();

    int* subisFixed{};
    int* subareFixed{};
    int size{};
    int isNum{};
    int areNum{};
    int* isFixed{};
    int* areFixed{};
};

class Tabu_Sol {
public:
    explicit Tabu_Sol(int itemNum);
    ~Tabu_Sol();
    void tabuSol(const Solution& sol) const;
    [[nodiscard]] bool judgeTabu(const Solution& sol, const Move& move);

    int tabuNum{};
    long int length{};
    double gamma1{};
    double gamma2{};
    double gamma3{};
    bool* hash1{};
    bool* hash2{};
    bool* hash3{};
    long long* weight1{};
    long long* weight2{};
    long long* weight3{};
};

// class Tabu_new {
// public:
//     explicit Tabu_new(int itemNum);
//     ~Tabu_new();
//     void updateInjection(const SubInstance & subIns);
//     void tabuSol(const Solution& sol) const;
//     [[nodiscard]] bool judgeTabu(const Solution& sol, const Move& move);

//     int tabuNum{};
//     long int length{};
//     double gamma1{};
//     double gamma2{};
//     double gamma3{};
//     bool* hash1{};
//     bool* hash2{};
//     bool* hash3{};
//     int* injection{};
//     long long* weight1{};
//     long long* weight2{};
//     long long* weight3{};
// };

class Frequency {
public:
    explicit Frequency(const Instance& ins);
    void initial(const ILP& solver);
    void initial();
    void updateFreq(Solution& sol);
    void updateFixed();
    void restoreFreq(Frequency& subFreq, const SubInstance& subIns);
    void flipFixed(const Solution& sol) const;
    void getFreqScore();
    void updateFixed(const bool* select,float* ILPscore,float beta);
    ~Frequency();

    int iter{};
    int total{};
    int size{};
    int fixNum{};
    double threshold{};
    double k{};
    bool lastSolFea{};
    int* freq{};
    int* isFixed{};
    float* score{};
};

class Func {
public:
    static void printVector(int* vector, int size);
    static void printMove(Move move);
    static void updateMoves(vector<Move>& moves, Move move);
    static void read(const string& path, const string& insNames, vector <string>& files);
};

class Sort {
public:
    Sort(const float* vector, int length);
    ~Sort();
    static void MergeSort(float* a, int* b, int left, int right);
    static void SingleLevelSort(float* a, int* b, int left, int right);

    float* data{};
    int* index{};
};

void flipNeighbor(const Instance& ins, const Solution& sol, Move& bestmove, Tabu_new& tabu, Output& output);
void swapNeighbor(const Instance& ins, const Solution& sol, Move& bestmove, Tabu_new& tabu, Output& output);
void tabuSearch(const SubInstance& ins, Solution& sol, Frequency& fModel, Input& input, Output& output);
void firstSearch(const Instance& ins, Solution& sol, Frequency& fModel, Input& input, Output& output);
void iterSearch(const Instance& ins, Input& input, Output& totalOutput);
void SEARCH(const Instance & ins ,Solution & sol,double timeLimit);
    
 
//void tabu(const Instance& ins, Solution& sol, Input& input, Output& output, const ILP& solver);
//void splitSearch(const Instance& mainIns, SubInstance& ins, Solution& bestSol, Input& input, Output& output);
//void insTree(string input_file);
#endif //MDMKP_TYPEDEF_H