#include "TypeDef.h"


Frequency::Frequency(const Instance& ins) {
    size = ins.itemNum;
    freq = new int[size];
    isFixed = new int[size];
    score = new float[size];
    initial();
}

void Frequency::initial(const ILP& solver){
    iter = 10000;
    k = solver.k;
    for (int item = 0;item < solver.size;item++) {
        double temp = solver.x[item];
        if (rand() % 10 > 8) {
            freq[item] = int(temp * iter);
        }
        else {
            freq[item] = int(0.5 * iter);
        }
    }
}

void Frequency::initial(){
    fixNum = 0;
    iter = 0;
    total = 0;
    lastSolFea = false;
    for (int item = 0; item < size; ++item) {
        freq[item] = 0;
        // isFixed[item] = 0;
        score[item] = 0;
    }
}

Frequency::~Frequency() {
    delete[] freq;
    delete[] isFixed;
    delete[] score;
}

void Frequency::updateFreq(Solution& sol) {
    iter++;
    for (int item = 0; item < size; ++item) {
        if (sol.select[item] == 1) {
            freq[item] += 1;
        }
    }
}

void Frequency::getFreqScore(){
    int f;
    if (iter != 0 ) {
        for (int item = 0; item < size; ++item) {
            isFixed[item] = 0;
            f = iter - freq[item];
            if (f < freq[item]) {
                score[item] = score[item] + 1.0 * (freq[item] - f) / (iter);
            }
            else {
                score[item] = score[item] + 1.0 * (f - freq[item]) / (iter);
            }
            freq[item] = 0;
        }
    }
    iter = 0;
}

void Frequency::updateFixed() {
    int* state = new int[size];
    int f;
    if (iter != 0 ) {
        for (int item = 0; item < size; ++item) {
            isFixed[item] = 0;
            f = iter - freq[item];
            if (f < freq[item]) {
                score[item] = score[item] + 1.0 * (freq[item] - f) / (iter);
                state[item] = 1;
            }
            else {
                score[item] = score[item] + 1.0 * (f - freq[item]) / (iter);
                state[item] = -1;
            }
            freq[item] = 0;
        }
    }
    Sort s(score, size);
    for (int fix = size - 1; fix >= size - fixNum; --fix) {
        isFixed[s.index[fix]] = state[s.index[fix]];
    }

    delete[] state;
}
void Frequency::updateFixed(const bool* select,float* ILPscore,float beta){
    for (int item = 0; item < size; ++item) {
        score[item] = score[item]*(1-beta) + ILPscore[item]*beta;
        if (isFixed[item]!=0){
            score[item] = score[item] * score[item];
        }
        printf("%3d:%.2f",item,score[item]);
        if (item%10==9) cout << endl;
    }
    cout << endl;
    for (int item = 0; item < size; ++item) {
        isFixed[item] = 0;
    }
    Sort s(score,size);
    for (int fix = size - 1; fix >= size - fixNum; --fix) {
        isFixed[s.index[fix]] = 2*select[s.index[fix]] - 1;
    }
 }

void Frequency::restoreFreq(Frequency& subFreq, const SubInstance& subIns) {
    iter = subFreq.iter;
    lastSolFea = subFreq.lastSolFea;
    total += iter;
    int subIndex = 0;
    for (int item = 0; item < size; ++item) {
        if (subIns.fixed[item] == 0) {
            freq[item] = subFreq.freq[subIndex++];
        }
        else if (subIns.fixed[item] == 1) {
            freq[item] = int(subFreq.iter * 0.95);
        }
        else if (subIns.fixed[item] == -1) {
            freq[item] = int(subFreq.iter * 0.05);
        }
    }
}

void Frequency::flipFixed(const Solution& sol) const {
    for (int item = 0; item < size; ++item) {
        if (isFixed[item] != 0) {
            isFixed[item] = 0;
        }
        else {
            if (sol.select[item]) {
                isFixed[item] = 1;
            }
            else {
                isFixed[item] = -1;
            }
        }
    }
}

void Sort::SingleLevelSort(float* a, int* b, int left, int right) {
    int mid = (left + right) / 2;
    //��һ���������ʼλ��
    int begin1 = left, end1 = mid;
    //�ڶ����������ʼλ��
    int begin2 = mid + 1, end2 = right;
    //tmp ������ʱ������кõ�����
    int size = right - left + 1;
    auto* tmp = new float[size];
    auto* tmp2 = new int[size];
    int p = 0;
    while (begin1 <= end1 && begin2 <= end2)
    {
        //begin2С����begin2������ʱ���飬begin2����ƶ�һλ
        if (a[begin1] > a[begin2])
        {
            tmp2[p] = b[begin2];
            tmp[p++] = a[begin2++];
        }
        else
        {
            tmp2[p] = b[begin1];
            tmp[p++] = a[begin1++];
        }
    }
    //������ʣ������䣬ƴ�ӵ�tmp�ĺ���
    while (begin1 <= end1)
    {
        tmp2[p] = b[begin1];
        tmp[p++] = a[begin1++];
    }
    while (begin2 <= end2)
    {
        tmp2[p] = b[begin2];
        tmp[p++] = a[begin2++];
    }
    //��ǰ����������������tmp�е����ݸ��µ�ԭ����
    for (size_t i = 0; i < size; i++)
    {
        //ע�� a ������ݵķ�Χ�� [left,right]
        // tmp������ݵķ�Χ��  [0,size-1]
        b[left + i] = tmp2[i];
        a[left + i] = tmp[i];
    }
    delete[] tmp;
    delete[] tmp2;
}

void Sort::MergeSort(float* a, int* b, int left, int right) {
    //����׶˵�ֻʣһ������ʱ���޷��ֽ⣬������һ��
    if (left >= right)
    {
        return;
    }
    //ȡ������м�λ�ã��ֳ�����С����
    int mid = (left + right) / 2;
    //�����䣬����ֽ�
    MergeSort(a, b, left, mid);
    //�����䣬���ҷֽ�
    MergeSort(a, b, mid + 1, right);
    //ֻ�зֽ⵽��׶˵�ʱ�򣬲ŻῪʼ�������������Ȼ��һ������������
    SingleLevelSort(a, b, left, right);
}

Sort::Sort(const float* vector, int length) {
    data = new float[length];
    index = new int[length];
    for (int i = 0; i < length; ++i) {
        data[i] = vector[i];
        index[i] = i;
    }
    MergeSort(data, index, 0, length - 1);

}

Sort::~Sort() {
    delete[] data;
    delete[] index;
}

