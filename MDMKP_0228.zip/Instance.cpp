#include "TypeDef.h"

Instance::Instance(string input_file) {
    unsigned int loc = input_file.find_last_of('/') + 1;
    while (input_file[loc] != '\0' && input_file[loc] != ' ') {
        insName.push_back(input_file[loc]);
        loc++;
    }
    const char* file = input_file.c_str();
    ifstream inputFile(file);
    if (!inputFile) {
        fprintf(stderr, "Can not open file %s\n", file);
        exit(10);
    }
    inputFile >> itemNum >> upperNum >> floorNum;
    attrNum = upperNum + floorNum;
    // ��ʼ��
    profit = new int[itemNum];
    threshold = new int[attrNum];
    attrType = new int[attrNum];
    resource = new int* [attrNum];
    for (int attr = 0; attr < attrNum; ++attr) {
        resource[attr] = new int[itemNum];
        if (attr < upperNum) {
            attrType[attr] = 1;
        }
        else {
            attrType[attr] = -1;
        }
    }
    // ��ȡ����
    for (int item = 0; item < itemNum; ++item) {
        inputFile >> profit[item];
    }
    for (int upper = 0; upper < upperNum; ++upper) {
        for (int item = 0; item < itemNum; ++item) {
            inputFile >> resource[upper][item];
        }
    }
    for (int upper = 0; upper < upperNum; ++upper) {
        inputFile >> threshold[upper];
    }
    for (int floor = 0; floor < floorNum; ++floor) {
        for (int item = 0; item < itemNum; ++item) {
            inputFile >> resource[upperNum + floor][item];
        }
    }
    for (int floor = 0; floor < upperNum; ++floor) {
        inputFile >> threshold[upperNum + floor];
    }
}

Instance::~Instance() {
    for (int index = 0; index < attrNum; ++index) {
        delete[] resource[index];
    }
    delete[] profit;
    delete[] threshold;
    delete[] attrType;
    delete[] resource;
    //    cout << "The Instance has been deleted!" << endl;
}

void Instance::printInformation(Output& output) const {
    output.output_info += "InstanceInfo Ins_Name            : " + insName + "\n";
    output.output_info += "InstanceInfo Item_Num            : " + to_string(itemNum) + "\n";
    output.output_info += "InstanceInfo Upper_Limit_Num     : " + to_string(upperNum) + "\n";
    output.output_info += "InstanceInfo Floor_Limit_Num     : " + to_string(floorNum) + "\n";
}

Instance::Instance() = default;

SubInstance::SubInstance(const Instance& ins, const int* isFixed) {
    // isFixed is 0 (Not fixed),1 (fixed in),-1 (fixed out)
    int fixNum = 0;
    cout << "Fixed item:" << endl;
    for (int item = 0; item < ins.itemNum; ++item) {
        if (isFixed[item] != 0) {
            fixNum++;
            printf("%4d ",item);
            if (fixNum%10 == 0){cout << endl;}
        }
    }
    cout << endl;
    mainItemNum = ins.itemNum;
    insName = ins.insName + "_cut_" + to_string(fixNum);
    itemNum = ins.itemNum - fixNum;
    upperNum = ins.upperNum;
    floorNum = ins.floorNum;
    attrNum = ins.attrNum;
    profit = new int[itemNum];
    threshold = new int[attrNum];
    attrType = new int[attrNum];
    resource = new int* [attrNum];
    fixed = new int[ins.itemNum];
    leaveObj = 0;
    int index = 0;
    for (int item = 0; item < ins.itemNum; ++item) {
        fixed[item] = isFixed[item];
        if (isFixed[item] == 0) {
            profit[index] = ins.profit[item];
            index++;
        }
        else if (isFixed[item] == 1) {
            leaveObj = leaveObj + ins.profit[item];
        }
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        attrType[attr] = ins.attrType[attr];
        threshold[attr] = ins.threshold[attr];
        resource[attr] = new int[itemNum];
        index = 0;
        for (int item = 0; item < ins.itemNum; ++item) {
            if (isFixed[item] == 0) {
                resource[attr][index] = ins.resource[attr][item];
                //*(resource+attr+index) = *(ins.resource+attr+item);
                index++;
            }
            else if (isFixed[item] == 1) {
                threshold[attr] = threshold[attr] - ins.resource[attr][item];
            }
        }
    }
}

SubInstance::SubInstance(int itemNum, int upperNum, int floorNum,int totalItemNum){
    insName = " ";
    this->itemNum = itemNum;
    this->upperNum = upperNum;
    this->floorNum = floorNum;
    this->mainItemNum = totalItemNum;
    attrNum = upperNum + floorNum;
    leaveObj = 0;
    profit = new int[itemNum];
    threshold = new int[attrNum];
    attrType = new int[attrNum];
    resource = new int* [attrNum];
    fixed = new int[totalItemNum];
    for (int attr = 0; attr < attrNum; ++attr) {
        resource[attr] = new int[itemNum];
    }
}

void SubInstance::beCovered(const SubInstance& ins,int total){
    if (itemNum != ins.itemNum) {
        cerr << "The covered inss has different item number!" << endl;
    }
    if (attrNum != ins.attrNum) {
        cerr << "The covered inss has different attr number!" << endl;
    }
    insName = ins.insName;
    leaveObj = ins.leaveObj;
    for (int item = 0;item < itemNum;item++) {
        profit[item] = ins.profit[item];
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        threshold[attr] = ins.threshold[attr];
        attrType[attr] = ins.attrType[attr];
        for (int item = 0;item < itemNum;item++) {
            resource[attr][item] = ins.resource[attr][item];
        }
    }
    for (int item = 0;item < total;item++) {
        fixed[item] = ins.fixed[item];
    }
}

SubInstance::~SubInstance() {
    delete[] fixed;
}
