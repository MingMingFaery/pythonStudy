#include "TypeDef.h"

void Func::printVector(int* vector, int size) {
    for (int index = 0;index < size;index++) {
        printf("index %3d: %7d\n", index, vector[index]);
    }
}

void Func::updateMoves(vector<Move>& moves, Move move) {
    if (moves.empty() || move.eva > moves[0].eva) {
        moves.clear();
        moves.push_back(move);
    }
    else if (move.eva == moves[0].eva) {
        moves.push_back(move);
    }

}

void Func::printMove(Move move) {
    if (move.flip == EMPTY) {
        printf("Swap in/out %5d / %5d , obj/fea/eva: %7d / %7.2f(%3d) / %7.2f!\n", move.inItem, move.outItem, move.obj, move.feasible, move.feaNum, move.eva);
    }
    else {
        if (move.in == 1) {
            printf("Flip loc %5d in         , obj/fea/eva: %7d / %7.2f(%3d) / %7.2f!\n", move.flip, move.obj, move.feasible, move.feaNum, move.eva);
        }
        else {
            printf("Flip loc %5d out        , obj/fea/eva: %7d / %7.2f(%3d) / %7.2f!\n", move.flip, move.obj, move.feasible, move.feaNum, move.eva);
        }
    }
}

void Func::read(const string& path, const string& insNames, vector <string>& files) {
    const char* file = insNames.c_str();
    ifstream inputFile(file);
    if (!inputFile) {
        fprintf(stderr, "Can not open file %s\n", file);
        exit(10);
    }
    string temp;
    while (getline(inputFile, temp)) {
        files.push_back(path + "/" + temp);
    }
    inputFile.close();
}
