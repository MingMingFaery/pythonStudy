#include "TypeDef.h"

int main() {
    string input_file = R"(../ins/100-30-30-1-5-15.txt )";
    Instance ins(input_file);
    Solution sol(ins);

    SEARCH(ins,sol,10);
    return 0;
}
