#include "TypeDef.h"

int main(int argc, char* argv[]) {
    int a = 0;
    if (argc>0){
        a = atoi(argv[argc-1]);
    }
    string input_file = R"(../ins/250-10-10-1-1.txt )";
    Instance ins(input_file);
    Solution sol(ins);
    SEARCH(ins,sol,30+a);
    return 0;
}
