#include "TypeDef.h"

Solution::Solution(const Instance& ins) {
    feaNum = -1;
    itemNum = ins.itemNum;
    attrNum = ins.attrNum;
    select = new bool[ins.itemNum];
    occupy = new int[ins.attrNum];
    attrFeasible = new int[ins.attrNum];
    attrGamma = new double[ins.attrNum];
    tabuLoc = new long long [3] {0, 0, 0};
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        attrFeasible[attr] = 0;
        occupy[attr] = 0;
        attrGamma[attr] = 0;
    }
}

void Solution::initialize_random(const Instance& ins,double gammaBase) {
    for (int item = 0; item < ins.itemNum; item++) {
        select[item] = rand() % 2;
    }
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        attrGamma[attr] = gammaBase;
    }
    evaluate(ins);
}

Solution::~Solution() {
    delete[] select;
    delete[] attrFeasible;
    delete[] occupy;
    delete[] attrGamma;
    //    cout << "The Solution has been deleted!" << endl;
}

void Solution::printInformation(Output& output) const {
    output.output_info += "SolutionInfo obj                 : " + to_string(obj) + "\n";
    output.output_info += "SolutionInfo fea                 : " + to_string(feasible) + "\n";
    output.output_info += "SolutionInfo feaNum              : " + to_string(feaNum) + "\n";
    output.output_info += "SolutionInfo eva                 : " + to_string(eva) + "\n";

}

void Solution::evaluate(const Instance& ins) {
    obj = 0;
    k = 0;
    for (int item = 0; item < itemNum; ++item) {
        obj += select[item] * ins.profit[item];
        k += select[item];
    }
    feasible = 0;
    feaNum = 0;
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        int tempResource = 0;
        for (int item = 0; item < itemNum; ++item) {
            tempResource += select[item] * ins.resource[attr][item];
        }
        occupy[attr] = tempResource;
        attrFeasible[attr] = ins.attrType[attr] * (ins.threshold[attr] - tempResource);
        if (attrFeasible[attr] < 0) {
            feaNum++;
            feasible += -attrFeasible[attr] * attrGamma[attr];
        }
    }
    eva = 1.0 * obj - feasible;
}

void Solution::printSol(const Instance& ins) const {
    cout << "Solution:" << endl;
    for (int item = 0; item < itemNum; ++item) {
        printf("%5d(%d)  ", ins.profit[item], select[item]);
    }
    cout << "= " << obj << endl;
    for (int attr = 0; attr < ins.attrNum; ++attr) {
        for (int item = 0; item < itemNum; ++item) {
            printf("%5d(%d)  ", ins.resource[attr][item], select[item]);
        }
        cout << "= " << attrFeasible[attr] << endl;

    }
}

void Solution::execute(const Instance& ins, Move move, const Input& input) {
    double temp = 0;
    feaNum = 0;
    if (move.flip == EMPTY) {
        select[move.inItem] = 1 - select[move.inItem];
        select[move.outItem] = 1 - select[move.outItem];
        //    evaluate(ins); // nm
        obj = move.obj;
        feasible = move.feasible;
        eva = move.eva;
        //        feaNum = move.feaNum;
        for (int attr = 0; attr < ins.attrNum; ++attr) {
            attrFeasible[attr] = attrFeasible[attr] - ins.attrType[attr] * (ins.resource[attr][move.inItem] - ins.resource[attr][move.outItem]);
            if (attrFeasible[attr] < 0) {
                feaNum++;
                temp += -attrFeasible[attr] * attrGamma[attr];
                attrGamma[attr] += input.gamma;
            }
        }
    }
    else {
        if (select[move.flip] > 0) {
            k = k - 1;
        }
        else {
            k = k + 1;
        }
        select[move.flip] = 1 - select[move.flip];
        //    evaluate(ins); // nm
        obj = move.obj;
        feasible = move.feasible;
        eva = move.eva;
        //        feaNum = move.feaNum;

        for (int attr = 0; attr < ins.attrNum; ++attr) {
            attrFeasible[attr] = attrFeasible[attr] - ins.attrType[attr] * move.in * ins.resource[attr][move.flip];
            if (attrFeasible[attr] < 0) {
                feaNum++;
                temp += -attrFeasible[attr] * attrGamma[attr];
                attrGamma[attr] += input.gamma;
            }
        }
    }
    if (temp != feasible || feaNum != move.feaNum) {
        cout << "Execute has mistake in iter " << temp << "//" << feasible << endl;
    }
    if (feasible == 0) {
        for (int attr = 0; attr < attrNum; ++attr) {
            attrGamma[attr] = input.gammaBase;
        }
    }
    gamma = 0;
    for (int attr = 0; attr < attrNum; ++attr) {
        gamma += attrGamma[attr];
    }
}

void Solution::beCovered(const Solution& sol) {
    k = sol.k;
    obj = sol.obj;
    feasible = sol.feasible;
    eva = sol.eva;
    feaNum = sol.feaNum;
    gamma = sol.gamma;
    for (int item = 0; item < itemNum; ++item) {
        select[item] = sol.select[item];
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        occupy[attr] = sol.occupy[attr];
        attrFeasible[attr] = sol.attrFeasible[attr];
        attrGamma[attr] = sol.attrGamma[attr];
    }
    for (int loc = 0; loc < 3; ++loc) {
        tabuLoc[loc] = sol.tabuLoc[loc];
    }

}

void Solution::output(const string& file, const Instance& ins) const {
    ofstream dataFile;
    dataFile.open(file);// ׷�� ofstream::app
    if (!dataFile.is_open()) {
        fprintf(stderr, "Can not open file %s\n", file.c_str());
        exit(10);
    }
    //    dataFile << "vertexNumber "<<"edgeNumber "<<"objectValue "<<"injection(candidateGraphVertex : hostGraphIndex)"<<endl;
    dataFile << itemNum << " " << ins.upperNum << " " << ins.floorNum << " " << obj << endl;
    for (int item = 0; item < itemNum; ++item) {
        dataFile << select[item] << endl;
    }
    dataFile.close();
}

void Solution::check(const Instance& ins, Output& output) const {
    int judge = 0;
    int obj_check = 0;
    for (int item = 0; item < itemNum; ++item) {
        obj_check += select[item] * ins.profit[item];
    }
    if (obj_check != obj) {
        judge = 1;
    }
    for (int attr = 0; attr < attrNum; ++attr) {
        int tempOccupy = 0;
        for (int item = 0; item < itemNum; ++item) {
            tempOccupy += select[item] * ins.resource[attr][item];
        }
        //        cout << tempOccupy << endl;
        if (ins.attrType[attr] == 1 && tempOccupy > ins.threshold[attr]) {
            judge = 2;
        }
        else if (ins.attrType[attr] != 1 && tempOccupy < ins.threshold[attr]) {
            judge = 3;
        }
    }
    output.output_info += "check               : ";
    if (judge == 0) {
        output.output_info += "No mistake!!\n";
    }
    else if (judge == 1) {
        output.output_info += "Obj has mistake!!\n";
    }
    else if (judge == 2) {
        output.output_info += "upper limit!!\n";
    }
    else {
        output.output_info += "floor limit!!\n";
    }

}

void Solution::save_solution(const Instance& ins, Output& output) const {
    output.sol_temp += ins.insName + " " + to_string(obj) + " ";
    for (int item = 0; item < itemNum; ++item) {
        output.sol_temp += to_string(select[item]);
    }
    output.sol_temp += "\n\n";
}

void Solution::getTabuScore(const long long* weight1, const long long* weight2, const long long* weight3) const {
    tabuLoc[0] = 0;
    tabuLoc[1] = 0;
    tabuLoc[2] = 0;
    for (int item = 0;item < itemNum;item++) {
        if (select[item]) {
            tabuLoc[0] += weight1[item];
            tabuLoc[1] += weight2[item];
            tabuLoc[2] += weight3[item];
        }
    }
}

// void Solution::getTabuScore(Tabu_new& tabu, const SubInstance& subIns) const {
//     tabuLoc[0] = 0;
//     tabuLoc[1] = 0;
//     tabuLoc[2] = 0;
//     int index = 0;
//     for (int item = 0;item < subIns.mainItemNum;item++) {
//         if (subIns.fixed[item] == 1) {
//             tabuLoc[0] += tabu.weight1[item];
//             tabuLoc[1] += tabu.weight2[item];
//             tabuLoc[2] += tabu.weight3[item];
//         }
//         else if (subIns.fixed[item] == 0) {
//             if (select[index] == 1) {
//                 tabuLoc[0] += tabu.weight1[item];
//                 tabuLoc[1] += tabu.weight2[item];
//                 tabuLoc[2] += tabu.weight3[item];
//             }
//             index++;
//         }
//     }
// }

void Solution::restoreSol(const Solution& subSol, const Instance& mainIns, const SubInstance& subIns) {
    int subIndex = 0;
    for (int item = 0; item < itemNum; ++item) {
        if (subIns.fixed[item] == 0) {
            select[item] = subSol.select[subIndex++];
        }
        else {
            select[item] = (subIns.fixed[item] + 1) / 2;
        }
    }
    evaluate(mainIns);
    if (obj != subSol.obj + subIns.leaveObj) {
        cout << "Restoring has mistake!" << endl;
    }
}

