#include "TypeDef.h"

void Output::printOutput() {
    output_info += "OutputTime   totalTime           : " + to_string(totalTime) + "\n";
    output_info += "OutputTime   FlipTime            : " + to_string(100 * flipTime / totalTime) + "%\n";
    output_info += "OutputTime   SwapTime            : " + to_string(100 * swapTime / totalTime) + "%\n";
    output_info += "OutputTime   UpdateTime          : " + to_string(100 * updateTime / totalTime) + "%\n";
    output_info += "OutputTime   findBestTime        : " + to_string(findBestTime) + "\n";
    output_info += "OutputInfo   iter                : " + to_string(iter) + "\n";
    output_info += "OutputInfo   stagnant            : " + to_string(stagnant) + "\n";
}

void Output::output(const string& file) const {
    ofstream dataFile;
    dataFile.open(file, ofstream::app);// ׷�� ofstream::app
    if (!dataFile.is_open()) {
        fprintf(stderr, "Can not open file %s\n", file.c_str());
        exit(10);
    }
    //    dataFile << "vertexNumber "<<"edgeNumber "<<"objectValue "<<"injection(candidateGraphVertex : hostGraphIndex)"<<endl;
    time_t timep;
    time(&timep);
    char tmp[64];
    struct tm nowTime;
    localtime_s(&nowTime, &timep);
    strftime(tmp, sizeof(tmp), "%Y-%m-%d-%H:%M:%S", &nowTime);
    dataFile << "Now is          : " << tmp << endl;
    dataFile << output_info << endl;
    dataFile << iter_info << endl;
    dataFile << "-------------------------" << endl;
    dataFile.close();
    //    cout << output_info << endl;
}

void Output::output_sol(const string& file) const {
    ofstream dataFile;
    dataFile.open(file, ofstream::app);// ׷�� ofstream::app
    if (!dataFile.is_open()) {
        fprintf(stderr, "Can not open file %s\n", file.c_str());
        exit(10);
    }
    //    dataFile << "vertexNumber "<<"edgeNumber "<<"objectValue "<<"injection(candidateGraphVertex : hostGraphIndex)"<<endl;
    time_t timep;
    time(&timep);
    char tmp[64];
    struct tm nowTime;
    localtime_s(&nowTime, &timep);
    strftime(tmp, sizeof(tmp), "%Y-%m-%d-%H:%M:%S", &nowTime);
    dataFile << "Sol : Now is          : " << tmp << endl;
    dataFile << sol_temp << endl;
    dataFile.close();
}

Output::Output() {
    beginTime = clock();
    iter_info += Output::format("iter", 4);
    iter_info += Output::format("stag", 4);
    iter_info += Output::format("iterNum");
    iter_info += Output::format("time");
    iter_info += Output::format("totalT");
    iter_info += Output::format("itemN", 5);
    iter_info += Output::format("subSolObj", 10);
    iter_info += Output::format("solObj");
    iter_info += Output::format("feaNum");
    iter_info += Output::format("k", 5);
    iter_info += Output::format("bestObj");
    iter_info += "\n";
}

string Output::format(const string& str, int length) {
    string s;
    if (str.size() < length) {
        for (int index = 0; index < length - str.size(); ++index) {
            s += " ";
        }
        s += str;
    }
    else {
        s += str;
    }
    s += "|";
    return s;
}

string Output::formati(const int& a, int length) {
    string str = to_string(a);
    return format(str, length);
}

string Output::formatf(const float& b, int length) {
    string str;
    string str1 = to_string(b);
    unsigned int loc = str1.find_first_of(to_string(1.1)[1]) + 3;
    for (int l = 0; l < loc; l++) {
        str += str1[l];
    }
    return format(str, length);
}

void Output::getSubInfo(const Output& subOutput) {
    //    findBestTime = totalTime + subOutput.findBestTime;
    swapTime += subOutput.swapTime;
    flipTime += subOutput.flipTime;
    updateTime += subOutput.updateTime;
    tabuNum += subOutput.tabuNum;
}
Input::Input(int seed){
    inputInitial(seed);
}
void Input::inputInitial(int seed0, double timeLimit0, int improveCut0, double gamma0, double gamma_base0) {
    this->improveCut = improveCut0;
    this->seed = seed0;
    this->subTimeLimit = timeLimit0;
    this->gamma = gamma0;
    this->gammaBase = gamma_base0;
    fea = false;
    srand(this->seed);
}
void Input::printInput(Output& output) const {
    output.output_info += "Termination  MaxIter             : " + to_string(allIter) + "\n";
    output.output_info += "Termination  timeLimit           : " + to_string(timeLimit) + "\n";
    output.output_info += "Termination  improveCutAdd       : " + to_string(improveCutAdd) + "\n";
    output.output_info += "Termination  subImproveCut       : " + to_string(improveCut) + "\n";
    output.output_info += "Termination  subTimeLimit        : " + to_string(subTimeLimit) + "\n";
    output.output_info += "Parameter    seed                : " + to_string(seed) + "\n";
    output.output_info += "Parameter    cutRate             : " + to_string(cutRate) + "\n";
    output.output_info += "Parameter    gamma               : " + to_string(gamma) + "\n";
    output.output_info += "Parameter    gammaBase           : " + to_string(gammaBase) + "\n";

}